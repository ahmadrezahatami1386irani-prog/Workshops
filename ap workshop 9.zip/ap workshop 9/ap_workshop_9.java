import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashSet;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ap_workshop_9 {

    static String longest;
    static String shortest;
    static int sum_of_lengh_word;
    static HashSet<String> word_list;

    static {
        longest = null;
        shortest = null;
        sum_of_lengh_word = 0;
        word_list = new HashSet<>();
    }

    public static void main(String[] args) {
        ExecutorService executorService =Executors.newCachedThreadPool();
        for (int i = 1; i <= 20; i++) {
            executorService.execute(new thread_sampel("file_" + i + ".txt"));}
        executorService.shutdown();
        while (!executorService.isTerminated()) {}
        Scanner order = new Scanner(System.in);
        int temp = 0;
        while (temp != 5) {
            System.out.println("1-word count\n2-longest\n3-shortest\n4-average\n5-exit");
            temp = order.nextInt();
            switch (temp) {
                case 1:{
                    System.out.println(word_list.size());
                    break;}
                case 2:{
                    if (longest != null)
                        System.out.println(longest+"     length="+longest.length());
                    break;}
                case 3:{
                    if (shortest != null)
                        System.out.println(shortest+"    length="+shortest.length());
                    break;}
                case 4:{
                    if (word_list.size() != 0) {
                        float average =(float)sum_of_lengh_word/word_list.size();
                        System.out.println(average);
                    } 
                    else {
                        System.out.println(0);
                    }
                    break;
                }
                case 5:
                    break;
                default:
                    System.out.println("invalid order!");
            }
        }
        order.close();
    }
    public static synchronized void read_file(String file_name) {
        try (BufferedReader reader =new BufferedReader(new FileReader(file_name))){
            String word;
            while ((word = reader.readLine()) != null) {
                word = word.toLowerCase();
                if (!word_list.contains(word)) {
                    word_list.add(word);
                    sum_of_lengh_word += word.length();
                    if (longest == null || word.length() > longest.length()) {longest = word;}
                    if (shortest == null || word.length() < shortest.length()) {shortest = word;}
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
class thread_sampel implements Runnable {
    private String file_name;
    public thread_sampel(String file_name) {
        this.file_name = file_name;
    }
    @Override
    public void run() {
        ap_workshop_9.read_file(file_name);
    }
}